# Це переклад Risk of Rain 2 українською мовою. 
А це пам'ятник свині... Кхе...

Ось переклад, качайте, грайте, ніколи не використовуйте російську і радійте

Цей переклад підтримується тільки як мод і не може бути встановлений в теку Language без попередніх змін, тому якщо хочете переклад гри без модів - качайте переклад з гугл диску, якщо вам треба переклад модів, то ви вже знаєте як скачувати моди.

Discord сервер української спільноти Risk of Rain 2: https://discord.gg/36vHZPUtSW
# Вміст

* Основна гра
* DLC Survivors of the Void
* Та модифікації:
	* LostInTransit
	* Forgotten Relics
	* TeammateRevival
	* MinerUnearthed
	* RiskyMod (В розробці)
	* MysticsItems
* Переклад зі сторони мода:
    * Starstorm 2
	* HAND_OVERCLOCKED
	* ChefMod
	* SniperClassic
	* Tesla_Trooper
	* Direseeker
	* Risky_Artifacts
	* ProperSave
	* BetterUI
	* FogboundLagoon
# Встановлення
Thunderstore Launcher - тицніть кнопку "встановити" і готово

Manual, як мод - беріть папочку Risk_of_Rain_2_Ukrainian і кидайте її в Plugins за шляхом Steam\steamapps\common\Risk of Rain 2\BepInEx\plugins

Manual, як не мод - з Google Disk https://drive.google.com/file/d/1jNlrl3mcoqNTZtrxS21Zy5cbxgPKnDCS/view?usp=share_link
# Інші джерела завантаження
[GitHub](https://github.com/Damglador/UA-Risk-of-Rain-2): Найскоріші оновлення

[Посібник Steam](https://steamcommunity.com/sharedfiles/filedetails/?id=2887168591): Найновіша інфа, інші посилання і тд

[Google Disk](https://drive.google.com/file/d/1jNlrl3mcoqNTZtrxS21Zy5cbxgPKnDCS/view?usp=share_link)
# Подяка за переклад
Номер: 5375411200135544 (Переказ як на картку)

<details>
<summary>QR:</summary> 

[![QR](https://i.imgur.com/by6E4OP.png)](https://i.imgur.com/by6E4OP.png)
</details>

# Скріншоти
<details>
<summary>Vanilla</summary>

[![Меню](https://cdn.discordapp.com/attachments/1039459967238942723/1046142871008464906/image.png)](https://cdn.discordapp.com/attachments/1039459967238942723/1046142871008464906/image.png)
[![Музика](https://cdn.discordapp.com/attachments/1039459967238942723/1046142900804788244/image.png)](https://cdn.discordapp.com/attachments/1039459967238942723/1046142900804788244/image.png)
[![Записник, предмети](https://cdn.discordapp.com/attachments/1039459967238942723/1046142833851125800/image.png)](https://cdn.discordapp.com/attachments/1039459967238942723/1046142833851125800/image.png)
[![Записник, монстри](https://cdn.discordapp.com/attachments/1039459967238942723/1046143652222746706/image.png)](https://cdn.discordapp.com/attachments/1039459967238942723/1046143652222746706/image.png)
[![Записник, персонажі](https://cdn.discordapp.com/attachments/1039459967238942723/1046143681368948756/image.png)](https://cdn.discordapp.com/attachments/1039459967238942723/1046143681368948756/image.png)
</details>

<details>
<summary>Mods</summary>

[![HAN-D](https://cdn.discordapp.com/attachments/745054179847962741/1050218240997085224/image.png)](https://cdn.discordapp.com/attachments/745054179847962741/1050218240997085224/image.png)
[![Гірник](https://cdn.discordapp.com/attachments/745054179847962741/1050218129319526420/image.png)](https://cdn.discordapp.com/attachments/745054179847962741/1050218129319526420/image.png)
[![Снайпер](https://cdn.discordapp.com/attachments/745054179847962741/1050218171547795466/image.png)](https://cdn.discordapp.com/attachments/745054179847962741/1050218171547795466/image.png)
[![ШЕФ](https://cdn.discordapp.com/attachments/745054179847962741/1050218194645831680/image.png)](https://cdn.discordapp.com/attachments/745054179847962741/1050218194645831680/image.png)
</details>

## Список змін
<details>
<summary>1.3.3</summary>

* Спроба перекласти мод Ancient Scepter
* Виправлені деякі помилки
* Worm тепер Хробак, а не змій, через наявність Wurm в першій частині
<details>
<summary>1.3.2</summary>

* Видалено переклад для Enforcer, бо він ломав числа і неправильно працював
* Переклад SniperClassic тепер в самому моді
* Доробив і скинув розробу переклад TeslaTrooper
* Переклад BetterUI тепер в самому моді
</details>
<details>
<summary>1.3.1</summary>

* Переклад FogboundLagoon тепер в самому моді
* Переклад HAND_OVERCLOCKED тепер в самому моді
</details>
<details>
<summary>1.3.0</summary>

* Такого в русні точно нема, додані роди для префіксів еліток, тепер не "Палаючий Королева жуків", а "Палаюча", не "Полімерний мисливиця", а "Полімерна".
</details>
<details>
<summary>1.2.9</summary>

* Додано переклад моду Forgotten Relics (Зразу після релізу підтримки для перекладу)
* Дороблено більшість коротких та детальних описів предметів в MysticsItems, щоб це оновлення не було таким пустим
</details>
<details>
<summary>1.2.8</summary>

* Перенесено переклад модів в самі моди:
	* Direseeker
	* Risky_Artifacts
	* ProperSave
* Додано переклад моду Tesla_Trooper для тестування, в релізній версії моду не працює
</details>
<details>
<summary>1.2.7</summary>

* Почато переклад MysticsItems
* Додано переклад Fogbound Laghoon до моменту офіційного оновлення
* Максимально можливий повний переклад BetterUI (Дуже дякую розробнику за швидку співпрацю <3)
	* Деякі приколи з BetterUI пов'язані з іншими модами
* Схоже, що ще переклад моду Enforcer. Погано працюючий, але є
</details>
<details>
<summary>1.2.6</summary>

* Шматок ванільного записника, який скинув кіт
* Переклад приміток в записнику до деяких предметів Starstorm 2
* Переклад віконця в головному меню для BetterUI
</details>
<details>
<summary>1.2.5</summary>

* Переклад моду "LostInTransit" (Все окрім приміток в записнику)
* Переклад моду "Direseeker"
* Видалено стрічки, які не використовуються
* Переклад приміток до:
	* HAN-D
	* Гірника
	* Капітана
	* Рейкотронщиці
	* Немезиди Коммандо
	* Жахошукача
* Трохи оновлені кольори в TeammateRevival, щоб вони більше вписувалися в гру
</details>
<details>
<summary>1.2.4</summary>

* Повний переклад моду ChefMod
* Розпочатий переклад моду Risky Mod 
* Повний переклад моду Risky Artifacts
* Оновлення перекладу HAN-D до оновлення моду, додано новий вигляд
* Переклад моду FogboundLagoon версії вище 1.0.5 (Зі сторони моду, для працездатності потрібно, щоб папка мови називалася UA, для деталей пишіть в діскорд, або якщо не працює пишіть в діскорд)


</details>
<details>
<summary>1.2.3</summary>

* Переклад підказок до всіх персонажів (Включно з модовими)
* Переклад всіх детальних описів
* Виправлення помилок та закриття прогалин в перекладі
Переклад з сторони мода:
FogboundLagoon
Ці моди перекладені, але не в файлі перекладу, який ви скачуєте. І щоб переклад цих модів працював назва папки з українською мовою (Папка в якій знаходиться output-ukrainian.json) має бути UA
</details>

<details>
<summary>1.2.2</summary>

* Повний переклад моду "SniperClassic"
* Повний переклад моду "MinerUnearthed"
* Повний переклад моду "HAND OVERCLOCKED"

Як мінімум я переклав все, що відкрив сам, пізніше буде правитися та дороблюватися, але 99% вже готово
Очікую можливість перекласти Enforcer та Tesla Trooper. Spikestrip 2.0 було б непогано перекласти, але не думаю, що розроби зроблять можливість перекладу.
</details>

<details>
<summary>1.2.1</summary>

* Відремонтовано завантаження через Thunderstore Launcher
* В залежності доданий кириличний шрифт від русні
</details>

<details>
<summary>1.2.0</summary>

* Встановити переклад тепер можна з Thunderstore Launcher в один клік! (Дякую одному з розробників моду TeammateRevival)
* Переклад модів:
	* "HAND OVERCLOCKED", (Майже нульовий)
	* "MinerUnearthed", (Мало)
* Переклад моду TeammateRevival
* Переклад моду Starstorm 2
	* Персонажі та їх здібності
	* Всі досягнення
	* Всі предмети та їх короткі й повні описи
	* Не готово - описи персонажів і, по стандарту, примітки в записнику (тобто лор)
* Основна гра
	* Дороблений переклад налаштувань графіки та іншого
	* Більше детальних описів предметів
	* У Порожньої фляги тепер є опис, якщо грати з модом ItemStats (Сподіваюсь він вам сподобається)
	* Якісь нікому не потрібні фікси

Якщо будуть якісь правки чи неточності щодо перекладу - заходьте на Discord сервер і пишіть
</details>
<details>
<summary>1.1.2</summary>

* Персонажі та інше
	* Всі описи здібностей персонажів перекладені як і всі персонажі
	* Якісь нікому не потрібні фікси
	* Шмат моду Starstorm 2 перекладено
</details>