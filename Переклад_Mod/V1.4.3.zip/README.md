# Це переклад Risk of Rain 2 українською мовою. 
А це пам'ятник свині... Кхе...

Ось переклад, качайте, грайте, ніколи не використовуйте російську і радійте

Цей переклад підтримується тільки як мод і не може бути встановлений в теку Language без попередніх змін, тому якщо хочете переклад гри без модів - качайте переклад з гугл диску, якщо вам треба переклад модів, то ви вже знаєте як завантажувати моди.

Discord сервер української спільноти Risk of Rain 2: https://discord.gg/36vHZPUtSW (будь ласка, доєднуйтесь)

Завершеність перекладу:
[![Crowdin](https://badges.crowdin.net/risk-of-rain-2-ua/localized.svg)](https://crowdin.com/project/risk-of-rain-2-ua)

# Вміст
* Основна гра
* DLC Survivors of the Void
* Та модифікації:
	* LostInTransit
	* Forgotten Relics
	* TeammateRevival
	* MinerUnearthed
	* RiskyMod (В розробці, нескінченній розробці)
	* MysticsItems
	* Enforcer
	* StandaloneAncientScepter
* Переклад зі сторони мода:
    * Starstorm 2
	* HAND_OVERCLOCKED
	* RMOR_REFORGED (Має бути)
	* ChefMod
	* Rocket (Має бути)
	* SniperClassic
	* Tesla_Trooper
	* Direseeker
	* Risky_Artifacts
	* ProperSave
	* BetterUI
	* FogboundLagoon
# В планах

* PaladinMod
# Встановлення
Thunderstore Launcher - тицніть кнопку "встановити" і готово

Manual, як мод - беріть теку Risk_of_Rain_2_Ukrainian і кидайте її в Plugins за шляхом Steam\steamapps\common\Risk of Rain 2\BepInEx\plugins

Manual, як не мод - з Google Disk https://drive.google.com/file/d/1jNlrl3mcoqNTZtrxS21Zy5cbxgPKnDCS/view?usp=share_link
# Корисні посилання
[GitHub](https://github.com/Damglador/UA-Risk-of-Rain-2): Найскоріші оновлення

[Посібник Steam](https://steamcommunity.com/sharedfiles/filedetails/?id=2887168591): Найновіша інфа, інші посилання тощо

[Google Disk](https://drive.google.com/file/d/1jNlrl3mcoqNTZtrxS21Zy5cbxgPKnDCS/view?usp=share_link): Для ванільної версії гри, як ставити дивіться в посібнику Steam

[Crowdin](https://uk.crowdin.com/project/risk-of-rain-2-ua): Тут ведеться переклад гри та в майбутньому буде вестися переклад Risk of Rain Returns. Але спочатку зайдіть на Discord сервер
# Шрифт
Крутий шрифт
[![Демонстрація шрифту](https://cdn.discordapp.com/attachments/1036544952164945920/1046542597042225173/image.png)](https://cdn.discordapp.com/attachments/1036544952164945920/1046542597042225173/image.png)
Мод також додає нормальний шрифт для кирилиці в гру
# Подяка за переклад
Номер: 5375411200135544 (Переказ як на картку)
Посилання: https://send.monobank.ua/jar/9fYeh5mu3Y
<details>
<summary>QR:</summary> 

[![QR](https://i.imgur.com/by6E4OP.png)](https://i.imgur.com/by6E4OP.png)
</details>

# Скріншоти
<details>
<summary>Vanilla</summary>

[![Меню](https://cdn.discordapp.com/attachments/1039459967238942723/1046142871008464906/image.png)](https://cdn.discordapp.com/attachments/1039459967238942723/1046142871008464906/image.png)
[![Музика](https://cdn.discordapp.com/attachments/1039459967238942723/1046142900804788244/image.png)](https://cdn.discordapp.com/attachments/1039459967238942723/1046142900804788244/image.png)
[![Записник, предмети](https://cdn.discordapp.com/attachments/1039459967238942723/1046142833851125800/image.png)](https://cdn.discordapp.com/attachments/1039459967238942723/1046142833851125800/image.png)
[![Записник, монстри](https://cdn.discordapp.com/attachments/1039459967238942723/1046143652222746706/image.png)](https://cdn.discordapp.com/attachments/1039459967238942723/1046143652222746706/image.png)
[![Записник, персонажі](https://cdn.discordapp.com/attachments/1039459967238942723/1046143681368948756/image.png)](https://cdn.discordapp.com/attachments/1039459967238942723/1046143681368948756/image.png)
</details>

<details>
<summary>Mods</summary>

[![HAN-D](https://cdn.discordapp.com/attachments/745054179847962741/1050218240997085224/image.png)](https://cdn.discordapp.com/attachments/745054179847962741/1050218240997085224/image.png)
[![Гірник](https://cdn.discordapp.com/attachments/745054179847962741/1050218129319526420/image.png)](https://cdn.discordapp.com/attachments/745054179847962741/1050218129319526420/image.png)
[![Снайпер](https://cdn.discordapp.com/attachments/745054179847962741/1050218171547795466/image.png)](https://cdn.discordapp.com/attachments/745054179847962741/1050218171547795466/image.png)
[![ШЕФ](https://cdn.discordapp.com/attachments/745054179847962741/1050218194645831680/image.png)](https://cdn.discordapp.com/attachments/745054179847962741/1050218194645831680/image.png)
</details>