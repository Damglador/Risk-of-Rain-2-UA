# Це переклад Risk of Rain 2 українською мовою. 
А це пам'ятник свині... Кхе...

Ось переклад, качайте, грайте, ніколи не використовуйте російську і радійте

Перекладено все, крім записів в записнику. Ну і описів персонажів... Але скоро буде!
Статус перекладу: ~80%

Discord сервер української спільноти Risk of Rain 2: https://discord.gg/36vHZPUtSW

# Встановлення
Thunderstore Launcher - тикніть кнопку "встановити" і готово

Manual як мод - беріть папочку Risk_of_Rain_2_Ukrainian і кидайте її в Plugins за шляхом Steam\steamapps\common\Risk of Rain 2\BepInEx\plugins

Manual як не мод - в скачаному zip файлі буде папка Localization, в ній папка UA, папку UA скопіювати і кинути в локальні файли гри за шляхом Steam\steamapps\common\Risk of Rain 2\Risk of Rain 2_Data\StreamingAssets\Language 
# Інші джерела завантаження
[GitHub](https://github.com/Damglador/UA-Risk-of-Rain-2): Найскоріші оновлення

[Посібник Steam](https://steamcommunity.com/sharedfiles/filedetails/?id=2887168591): Найновіша інфа, інші посилання і тд
# Подяка за переклад
Номер: 5375411200135544 (Переказ як на картку)

<details>
<summary>QR:</summary> 

[![QR](https://i.imgur.com/by6E4OP.png)](https://i.imgur.com/by6E4OP.png)
</details>

# Скріншоти
<details>
<summary>Розгорнути</summary>

[![Меню](https://cdn.discordapp.com/attachments/1039459967238942723/1046142871008464906/image.png)](https://cdn.discordapp.com/attachments/1039459967238942723/1046142871008464906/image.png)
[![Музика](https://cdn.discordapp.com/attachments/1039459967238942723/1046142900804788244/image.png)](https://cdn.discordapp.com/attachments/1039459967238942723/1046142900804788244/image.png)
[![Записник, предмети](https://cdn.discordapp.com/attachments/1039459967238942723/1046142833851125800/image.png)](https://cdn.discordapp.com/attachments/1039459967238942723/1046142833851125800/image.png)
[![Записник, монстри](https://cdn.discordapp.com/attachments/1039459967238942723/1046143652222746706/image.png)](https://cdn.discordapp.com/attachments/1039459967238942723/1046143652222746706/image.png)
[![Записник, персонажі](https://cdn.discordapp.com/attachments/1039459967238942723/1046143681368948756/image.png)](https://cdn.discordapp.com/attachments/1039459967238942723/1046143681368948756/image.png)
</details>

# Обов'язково поставте вподобайку перекладу!

## Список змін

<details>
<summary>1.2.3</summary>

* Переклад підказок до всіх персонажів (Включно з модовими)
* Переклад всіх детальних описів
* Виправлення помилок та закриття прогалин в перекладі
</details>

<details>
<summary>1.2.2</summary>

* Повний переклад моду "SniperClassic"
* Повний переклад моду "MinerUnearthed"
* Повний переклад моду "HAND OVERCLOCKED"

Як мінімум я переклав все, що відкрив сам, пізніше буде правитися та дороблюватися, але 99% вже готово
Очікую можливість перекласти Enforcer та Tesla Trooper, Spikestrip 2.0 було б непогано, але скоріше всього не буде (Бо неможливо).
</details>

<details>
<summary>1.2.1</summary>

* Відремонтовано завантаження через Thunderstore Launcher
* В залежності доданий кириличний шрифт від русні
</details>

<details>
<summary>1.2.0</summary>

* Встановити переклад тепер можна з Thunderstore Launcher в один клік! (Дякую одному з розробників моду TeammateRevival)
* Переклад модів:
	* "HAND OVERCLOCKED", (Майже нульовий)
	* "MinerUnearthed", (Мало)
	* "SniperClassic" (На цьому оновлені нема)
	* Їх переклад дуже сирий і його майже немає, але мені вже пора викладати оновлення
* Переклад моду TeammateRevival (Очікуйте оновлення моду з версії 4.1.3 на вищу)
* Переклад моду Starstorm 2
	* Персонажі та їх здібності
	* Всі досягнення
	* Всі предмети та їх короткі й повні описи
	* Не готово - описи персонажів і, по стандарту, примітки в записнику (тобто лор)
* Основна гра
	* Дороблений переклад налаштувань графіки та іншого
	* Більше детальних описів предметів
	* У Порожньої фляги тепер є опис, якщо грати з модом ItemStats (Сподіваюсь він вам сподобається)
	* Якісь нікому не потрібні фікси

Якщо будуть якісь правки чи неточності щодо перекладу - заходьте на Discord сервер і пишіть
</details>
<details>
<summary>1.1.2</summary>

* Персонажі та інше
	* Всі описи здібностей персонажів перекладені як і всі персонажів
	* Якісь нікому не потрібні фікси
	* Шмат моду Starstorm 2 перекладено
</details>